import random
import time

def intro():
    print("May I ask you for your name?")
    name = input()
    print(f"{name}, we are going to play a game. I am thinking of a number between 1 and 200.")
    time.sleep(0.5)
    print("Go ahead. Guess!")
    return name  # Return the name

def pick(name):  # Pass name as a parameter
    number = random.randint(1, 200)
    guesses_taken = 0
    max_guesses = 6
    while guesses_taken < max_guesses:
        enter = input("Guess: ")
        try:
            guess = int(enter)
            if 1 <= guess <= 200:
                guesses_taken += 1
                if guess < number:
                    print("The number you guessed is too low.")
                elif guess > number:
                    print("The number you guessed is too high.")
                else:
                    print(f"Congratulations, {name}! You guessed the number in {guesses_taken} guesses!")
                    return
                if guesses_taken < max_guesses:
                    print("Try again!")
            else:
                print("Please enter a number between 1 and 200.")
        except ValueError:
            print("Please enter a valid number.")

    print(f"Sorry, {name}. You've run out of guesses. The number I was thinking of was {number}.")

def play_again():
    return input("Do you want to play again? (yes/no): ").lower() in ["yes", "y"]

def main():
    while True:
        name = intro()  # Get the name
        pick(name)  # Pass the name to the pick function
        if not play_again():
            print("Thank you for playing!")
            break

if __name__ == "__main__":
    main()
